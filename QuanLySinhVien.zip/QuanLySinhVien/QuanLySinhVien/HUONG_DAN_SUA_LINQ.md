# 🎓 HƯỚNG DẪN SỬA LINQ ĐÚNG CÁCH - DỰ ÁN QUẢN LÝ SINH VIÊN

## ⚠️ VẤN ĐỀ PHÁT HIỆN

### ❌ **SAI: Code hiện tại vi phạm yêu cầu LINQ**

```csharp
// ❌ SAI: Dùng ADO.NET thuần túy
private void LoadStatistics()
{
    int totalStudents = StudentDataAccess.CountActiveStudents();
    // → Bên trong: SqlCommand.ExecuteScalar() - KHÔNG CÓ LINQ!
    
    int totalClasses = ClassDataAccess.CountClasses();
    // → Bên trong: SqlCommand + SqlDataReader - KHÔNG CÓ LINQ!
}
```

**Vì sao SAI?**
- ❌ Chỉ gọi helper method ADO.NET
- ❌ `SqlCommand.ExecuteScalar()` KHÔNG PHẢI LINQ
- ❌ `SqlDataReader.Read()` KHÔNG PHẢI LINQ
- ❌ Chỉ có LINQ trên UI controls (`OfType<>`) → Không đủ yêu cầu!

---

## ✅ **GIẢI PHÁP: Sử dụng LINQ to Objects**

### 🎯 **Nguyên tắc:**
1. Load dữ liệu từ Repository về `List<T>`
2. Dùng LINQ operators trên `List<T>` để query
3. **KHÔNG** gọi trực tiếp `SqlCommand` trong business logic

### ✅ **ĐÚNG: Code đã sửa**

```csharp
private void LoadStatistics()
{
    // Bước 1: Load dữ liệu từ Repository
    var allStudents = studentRepository.GetAllStudents();
    // → Trả về List<Student>
    
    // Bước 2: Dùng LINQ để đếm
    int totalStudents = allStudents.Count(s => s.IsActive);  // ✅ LINQ Count()
    
    // Bước 3: LINQ GroupBy + Select
    var studentsByGender = allStudents
        .Where(s => s.IsActive && !string.IsNullOrEmpty(s.Gender))  // ✅ LINQ Where()
        .GroupBy(s => s.Gender)                                      // ✅ LINQ GroupBy()
        .Select(g => new { Gender = g.Key, Count = g.Count() })     // ✅ LINQ Select()
        .ToList();
    
    // Bước 4: Hiển thị kết quả
    if (studentsByGender.Any())  // ✅ LINQ Any()
    {
        string genderStats = string.Join(", ", 
            studentsByGender.Select(g => $"{g.Gender}: {g.Count}"));  // ✅ LINQ Select()
    }
}
```

---

## 📊 **SO SÁNH LINQ vs ADO.NET**

| Tiêu chí | ADO.NET (SAI) | LINQ (ĐÚNG) |
|----------|---------------|-------------|
| **Cách đếm** | `SqlCommand.ExecuteScalar("SELECT COUNT(*)")` | `list.Count(x => x.IsActive)` |
| **Lọc dữ liệu** | `WHERE IsActive = 1` trong SQL | `list.Where(x => x.IsActive)` |
| **Nhóm dữ liệu** | `GROUP BY Gender` trong SQL | `list.GroupBy(x => x.Gender)` |
| **Sắp xếp** | `ORDER BY Name` trong SQL | `list.OrderBy(x => x.Name)` |
| **Lấy top N** | `TOP 10` trong SQL | `list.Take(10)` |

---

## 🛠️ **CÁC VỊ TRÍ CẦN SỬA TRONG DỰ ÁN**

### 1️⃣ **MainForm.cs** - ✅ ĐÃ SỬA

```csharp
// ❌ TRƯỚC (SAI):
int totalStudents = StudentDataAccess.CountActiveStudents();

// ✅ SAU (ĐÚNG):
var allStudents = studentRepository.GetAllStudents();
int totalStudents = allStudents.Count(s => s.IsActive);  // LINQ!
```

### 2️⃣ **StudentRepository.cs** - ⚠️ CẦN CẢI THIỆN

**Hiện tại:**
```csharp
public List<Student> GetAllStudents()
{
    // ❌ Load bằng ADO.NET
    using (SqlDataReader reader = cmd.ExecuteReader())
    {
        while (reader.Read())
        {
            students.Add(MapReaderToStudent(reader));
        }
    }
    
    // ✅ Chỉ có dòng này dùng LINQ
    return students.OrderBy(s => s.StudentName).ToList();
}
```

**Đánh giá:**
- ✅ CHẤP NHẬN được vì Repository layer CÓ THỂ dùng ADO.NET để load
- ✅ LINQ được dùng ở tầng Business Logic (MainForm, Service layer)
- ✅ Quan trọng: Các method `Search`, `Filter` phải dùng LINQ

### 3️⃣ **Các method CẦN DÙNG LINQ**

#### ✅ **SearchStudent() - ĐÃ ĐÚNG**
```csharp
public List<Student> SearchStudent(string keyword)
{
    var allStudents = GetAllStudents();
    
    // ✅ LINQ: Where + Contains
    return allStudents
        .Where(s =>
            s.StudentName.Contains(keyword, StringComparison.OrdinalIgnoreCase) ||
            s.StudentCode.Contains(keyword, StringComparison.OrdinalIgnoreCase) ||
            (s.Email != null && s.Email.Contains(keyword))
        )
        .OrderBy(s => s.StudentName)  // ✅ LINQ OrderBy
        .ToList();
}
```

#### ✅ **GetStudentsByClass() - ĐÃ ĐÚNG**
```csharp
public List<Student> GetStudentsByClass(int classId)
{
    var allStudents = GetAllStudents();
    
    // ✅ LINQ: Where + OrderBy
    return allStudents
        .Where(s => s.ClassID == classId && s.IsActive)
        .OrderBy(s => s.StudentName)
        .ToList();
}
```

#### ✅ **GetStudentCountByGender() - ĐÃ ĐÚNG**
```csharp
public Dictionary<string, int> GetStudentCountByGender()
{
    var students = GetAllStudents();
    
    // ✅ LINQ: Where + GroupBy + ToDictionary
    return students
        .Where(s => s.IsActive && !string.IsNullOrWhiteSpace(s.Gender))
        .GroupBy(s => s.Gender)
        .ToDictionary(g => g.Key!, g => g.Count());
}
```

---

## 📝 **CHECKLIST SỬA LINQ CHO TOÀN DỰ ÁN**

### ✅ **ĐÃ SỬA**
- [x] `MainForm.cs` → Dùng LINQ Count, Where, GroupBy, Select
- [x] `StudentRepository.cs` → Các method đã dùng LINQ

### ⚠️ **CẦN SỬA (PROMPT 7-9)**
- [ ] `ClassRepository.cs` → Phải dùng LINQ (Where, OrderBy, GroupBy...)
- [ ] `TeacherRepository.cs` → Phải dùng LINQ
- [ ] `ScoreRepository.cs` → Phải dùng LINQ
- [ ] `UserRepository.cs` → Phải dùng LINQ

### 🎯 **CÁC Form CẦN DÙNG LINQ**
- [ ] `StudentForm.cs` → Load DataGridView bằng LINQ
- [ ] `ClassForm.cs` → Load ComboBox bằng LINQ
- [ ] `ScoreForm.cs` → Tính điểm TB bằng LINQ Average()
- [ ] `ReportStudentForm.cs` → Filter + Sort bằng LINQ
- [ ] `ChartForm.cs` → GroupBy + Sum bằng LINQ

---

## 🎓 **CÁC LINQ OPERATORS PHẢI DÙNG**

### **Bắt buộc (Minimum 7 operators):**
1. ✅ `Where()` - Lọc dữ liệu
2. ✅ `Select()` - Chọn field
3. ✅ `OrderBy() / OrderByDescending()` - Sắp xếp
4. ✅ `GroupBy()` - Nhóm dữ liệu
5. ✅ `Count()` - Đếm
6. ✅ `Any()` - Kiểm tra tồn tại
7. ✅ `First() / FirstOrDefault()` - Lấy phần tử đầu

### **Nâng cao (Khuyến nghị):**
8. ✅ `Take()` - Lấy N phần tử
9. ✅ `Skip()` - Bỏ qua N phần tử
10. ✅ `Sum() / Average() / Min() / Max()` - Tính toán
11. ✅ `Join()` - Kết hợp 2 list
12. ✅ `Distinct()` - Loại bỏ trùng
13. ✅ `Contains()` - Kiểm tra chứa

---

## ⚠️ **LƯU Ý QUAN TRỌNG**

### ❌ **KHÔNG ĐẠT nếu:**
1. Chỉ dùng LINQ trên UI controls (`OfType<>`, `Cast<>`)
2. Dùng `SqlCommand.ExecuteScalar()` để đếm thay vì `Count()`
3. Dùng SQL `WHERE` thay vì LINQ `Where()`
4. Dùng SQL `GROUP BY` thay vì LINQ `GroupBy()`

### ✅ **ĐẠT YÊU CẦU nếu:**
1. Load dữ liệu về `List<T>` từ Repository
2. Dùng LINQ operators trên `List<T>` để query
3. Tối thiểu 7+ LINQ operators khác nhau
4. LINQ được dùng trong **Business Logic layer** (Form, Service)

---

## 🚀 **KẾ HOẠCH TRIỂN KHAI**

### **PROMPT 6** (✅ Hoàn thành)
- ✅ StudentRepository với LINQ
- ✅ MainForm với LINQ Count, Where, GroupBy

### **PROMPT 7** (Tiếp theo)
- [ ] ClassRepository với LINQ
- [ ] MainForm load Classes bằng LINQ
- [ ] ComboBox binding bằng LINQ

### **PROMPT 8**
- [ ] TeacherRepository với LINQ
- [ ] ScoreRepository với LINQ

### **PROMPT 9**
- [ ] UserRepository với LINQ
- [ ] StudentForm với LINQ DataGridView binding

---

## 📚 **VÍ DỤ MẪU CHO CÁC FORM**

### **StudentForm.cs**
```csharp
private void LoadData()
{
    var students = studentRepository.GetAllStudents();
    
    // ✅ LINQ: Where + OrderBy
    var displayStudents = students
        .Where(s => s.IsActive)
        .OrderBy(s => s.StudentName)
        .Select(s => new {
            s.StudentID,
            s.StudentCode,
            s.StudentName,
            s.Email,
            s.Phone
        })
        .ToList();
    
    dataGridView.DataSource = displayStudents;
}

private void SearchButton_Click(object sender, EventArgs e)
{
    string keyword = txtSearch.Text;
    
    // ✅ LINQ: Where với multiple conditions
    var results = studentRepository.GetAllStudents()
        .Where(s => 
            s.StudentName.Contains(keyword) || 
            s.StudentCode.Contains(keyword)
        )
        .ToList();
    
    dataGridView.DataSource = results;
}
```

### **ScoreForm.cs**
```csharp
private void CalculateAverage(int studentId)
{
    var scores = scoreRepository.GetScoresByStudent(studentId);
    
    // ✅ LINQ: Average
    double avgScore = scores.Average(s => (double)s.Score);
    
    // ✅ LINQ: Max, Min
    double maxScore = scores.Max(s => s.Score);
    double minScore = scores.Min(s => s.Score);
    
    // ✅ LINQ: GroupBy + Average
    var avgBySubject = scores
        .GroupBy(s => s.SubjectName)
        .Select(g => new {
            Subject = g.Key,
            Average = g.Average(s => (double)s.Score)
        })
        .ToList();
}
```

---

## ✅ **KẾT LUẬN**

- ✅ **MainForm.cs đã được sửa đúng** - Dùng LINQ Count, Where, GroupBy, Select
- ✅ **StudentRepository.cs đã đúng** - Các method Search, Filter dùng LINQ
- ⚠️ **Cần áp dụng pattern tương tự** cho ClassRepository, TeacherRepository, ScoreRepository
- 🎯 **Mục tiêu:** Tất cả business logic phải dùng LINQ, không gọi trực tiếp SQL

**YÊU CẦU TỐI THIỂU:** Mỗi Repository phải có ít nhất 7 LINQ operators khác nhau!

---

📅 **Ngày cập nhật:** 15/11/2025  
✍️ **Người viết:** GitHub Copilot  
🎯 **Mục đích:** Đảm bảo dự án đạt yêu cầu LINQ của giáo viên
