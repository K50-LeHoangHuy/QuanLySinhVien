namespace StudentManagement
{
    partial class AboutForm
    {
        private System.ComponentModel.IContainer components = null;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        private void InitializeComponent()
        {
            pnlHeader = new Panel();
            lblIcon = new Label();
            lblTitle = new Label();
            pnlContent = new Panel();
            lblGroupTitle = new Label();
            lblMemberName1 = new Label();
            lblMemberCode1 = new Label();
            lblMemberName2 = new Label();
            lblMemberCode2 = new Label();
            lblMemberName3 = new Label();
            lblMemberCode3 = new Label();
            lblMemberName4 = new Label();
            lblMemberCode4 = new Label();
            lblMemberName5 = new Label();
            lblMemberCode5 = new Label();
            btnClose = new Button();
            pnlHeader.SuspendLayout();
            pnlContent.SuspendLayout();
            SuspendLayout();
            // 
            // pnlHeader
            // 
            pnlHeader.BackColor = Color.FromArgb(70, 130, 180);
            pnlHeader.Controls.Add(lblIcon);
            pnlHeader.Controls.Add(lblTitle);
            pnlHeader.Dock = DockStyle.Top;
            pnlHeader.Location = new Point(0, 0);
            pnlHeader.Name = "pnlHeader";
            pnlHeader.Size = new Size(582, 80);
            pnlHeader.TabIndex = 0;
            // 
            // lblIcon
            // 
            lblIcon.Font = new Font("Segoe UI", 24F);
            lblIcon.ForeColor = Color.White;
            lblIcon.Location = new Point(20, 15);
            lblIcon.Name = "lblIcon";
            lblIcon.Size = new Size(50, 50);
            lblIcon.TabIndex = 0;
            lblIcon.Text = "📚";
            // 
            // lblTitle
            // 
            lblTitle.Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right;
            lblTitle.Font = new Font("Segoe UI", 16F, FontStyle.Bold);
            lblTitle.ForeColor = Color.White;
            lblTitle.Location = new Point(80, 20);
            lblTitle.Name = "lblTitle";
            lblTitle.Size = new Size(437, 30);
            lblTitle.TabIndex = 1;
            lblTitle.Text = "QUẢN LÝ SINH VIÊN";
            // 
            // pnlContent
            // 
            pnlContent.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            pnlContent.AutoScroll = true;
            pnlContent.BackColor = Color.White;
            pnlContent.BorderStyle = BorderStyle.FixedSingle;
            pnlContent.Controls.Add(lblGroupTitle);
            pnlContent.Controls.Add(lblMemberName1);
            pnlContent.Controls.Add(lblMemberCode1);
            pnlContent.Controls.Add(lblMemberName2);
            pnlContent.Controls.Add(lblMemberCode2);
            pnlContent.Controls.Add(lblMemberName3);
            pnlContent.Controls.Add(lblMemberCode3);
            pnlContent.Controls.Add(lblMemberName4);
            pnlContent.Controls.Add(lblMemberCode4);
            pnlContent.Controls.Add(lblMemberName5);
            pnlContent.Controls.Add(lblMemberCode5);
            pnlContent.Location = new Point(25, 100);
            pnlContent.Name = "pnlContent";
            pnlContent.Size = new Size(540, 400);
            pnlContent.TabIndex = 1;
            // 
            // lblGroupTitle
            // 
            lblGroupTitle.Font = new Font("Segoe UI", 12F, FontStyle.Bold);
            lblGroupTitle.ForeColor = Color.FromArgb(70, 130, 180);
            lblGroupTitle.Location = new Point(20, 20);
            lblGroupTitle.Name = "lblGroupTitle";
            lblGroupTitle.Size = new Size(200, 25);
            lblGroupTitle.TabIndex = 0;
            lblGroupTitle.Text = "👥 NHÓM 2TH\r\n\r\n\r\n";
            // 
            // lblMemberName1
            // 
            lblMemberName1.Font = new Font("Segoe UI", 11F, FontStyle.Bold);
            lblMemberName1.ForeColor = Color.FromArgb(51, 51, 51);
            lblMemberName1.Location = new Point(60, 55);
            lblMemberName1.Name = "lblMemberName1";
            lblMemberName1.Size = new Size(287, 22);
            lblMemberName1.TabIndex = 2;
            lblMemberName1.Text = "Phạm Nguyễn Trường Huy\r\n\r\n";
            // 
            // lblMemberCode1
            // 
            lblMemberCode1.Font = new Font("Segoe UI", 9F);
            lblMemberCode1.ForeColor = Color.Gray;
            lblMemberCode1.Location = new Point(60, 75);
            lblMemberCode1.Name = "lblMemberCode1";
            lblMemberCode1.Size = new Size(200, 18);
            lblMemberCode1.TabIndex = 3;
            lblMemberCode1.Text = "MSSV: 50.01.104.063";
            // 
            // lblMemberName2
            // 
            lblMemberName2.Font = new Font("Segoe UI", 11F, FontStyle.Bold);
            lblMemberName2.ForeColor = Color.FromArgb(51, 51, 51);
            lblMemberName2.Location = new Point(60, 105);
            lblMemberName2.Name = "lblMemberName2";
            lblMemberName2.Size = new Size(250, 22);
            lblMemberName2.TabIndex = 5;
            lblMemberName2.Text = "Trần Tâm";
            // 
            // lblMemberCode2
            // 
            lblMemberCode2.Font = new Font("Segoe UI", 9F);
            lblMemberCode2.ForeColor = Color.Gray;
            lblMemberCode2.Location = new Point(60, 125);
            lblMemberCode2.Name = "lblMemberCode2";
            lblMemberCode2.Size = new Size(200, 18);
            lblMemberCode2.TabIndex = 6;
            lblMemberCode2.Text = "MSSV: 50.01.104.142";
            // 
            // lblMemberName3
            // 
            lblMemberName3.Font = new Font("Segoe UI", 11F, FontStyle.Bold);
            lblMemberName3.ForeColor = Color.FromArgb(51, 51, 51);
            lblMemberName3.Location = new Point(60, 155);
            lblMemberName3.Name = "lblMemberName3";
            lblMemberName3.Size = new Size(250, 22);
            lblMemberName3.TabIndex = 8;
            lblMemberName3.Text = "Lê Hoàng Huy";
            // 
            // lblMemberCode3
            // 
            lblMemberCode3.Font = new Font("Segoe UI", 9F);
            lblMemberCode3.ForeColor = Color.Gray;
            lblMemberCode3.Location = new Point(60, 175);
            lblMemberCode3.Name = "lblMemberCode3";
            lblMemberCode3.Size = new Size(200, 18);
            lblMemberCode3.TabIndex = 9;
            lblMemberCode3.Text = "MSSV: 50.01.104.058";
            // 
            // lblMemberName4
            // 
            lblMemberName4.Font = new Font("Segoe UI", 11F, FontStyle.Bold);
            lblMemberName4.ForeColor = Color.FromArgb(51, 51, 51);
            lblMemberName4.Location = new Point(60, 205);
            lblMemberName4.Name = "lblMemberName4";
            lblMemberName4.Size = new Size(250, 22);
            lblMemberName4.TabIndex = 11;
            lblMemberName4.Text = "Võ Tấn Thiện";
            // 
            // lblMemberCode4
            // 
            lblMemberCode4.Font = new Font("Segoe UI", 9F);
            lblMemberCode4.ForeColor = Color.Gray;
            lblMemberCode4.Location = new Point(60, 225);
            lblMemberCode4.Name = "lblMemberCode4";
            lblMemberCode4.Size = new Size(200, 18);
            lblMemberCode4.TabIndex = 12;
            lblMemberCode4.Text = "MSSV: 50.01.104.153";
            // 
            // lblMemberName5
            // 
            lblMemberName5.Font = new Font("Segoe UI", 11F, FontStyle.Bold);
            lblMemberName5.ForeColor = Color.FromArgb(51, 51, 51);
            lblMemberName5.Location = new Point(60, 255);
            lblMemberName5.Name = "lblMemberName5";
            lblMemberName5.Size = new Size(250, 22);
            lblMemberName5.TabIndex = 14;
            lblMemberName5.Text = "Phạm Văn Phi";
            // 
            // lblMemberCode5
            // 
            lblMemberCode5.Font = new Font("Segoe UI", 9F);
            lblMemberCode5.ForeColor = Color.Gray;
            lblMemberCode5.Location = new Point(60, 275);
            lblMemberCode5.Name = "lblMemberCode5";
            lblMemberCode5.Size = new Size(200, 18);
            lblMemberCode5.TabIndex = 15;
            lblMemberCode5.Text = "MSSV: 50.01.104.115";
            // 
            // btnClose
            // 
            btnClose.Anchor = AnchorStyles.Bottom | AnchorStyles.Right;
            btnClose.BackColor = Color.FromArgb(70, 130, 180);
            btnClose.Cursor = Cursors.Hand;
            btnClose.FlatAppearance.BorderSize = 0;
            btnClose.FlatStyle = FlatStyle.Flat;
            btnClose.Font = new Font("Segoe UI", 10F, FontStyle.Bold);
            btnClose.ForeColor = Color.White;
            btnClose.Location = new Point(490, 520);
            btnClose.Name = "btnClose";
            btnClose.Size = new Size(80, 35);
            btnClose.TabIndex = 2;
            btnClose.Text = "Đóng";
            btnClose.UseVisualStyleBackColor = false;
            btnClose.Click += BtnClose_Click;
            // 
            // AboutForm
            // 
            BackColor = Color.FromArgb(240, 248, 255);
            ClientSize = new Size(582, 573);
            Controls.Add(pnlHeader);
            Controls.Add(pnlContent);
            Controls.Add(btnClose);
            MinimumSize = new Size(550, 580);
            Name = "AboutForm";
            StartPosition = FormStartPosition.CenterParent;
            Text = "Thông tin nhóm phát triển";
            pnlHeader.ResumeLayout(false);
            pnlContent.ResumeLayout(false);
            ResumeLayout(false);
        }

        #endregion

        private Panel pnlHeader;
        private Label lblIcon;
        private Label lblTitle;
        private Panel pnlContent;
        private Label lblGroupTitle;
        private Label lblMemberName1;
        private Label lblMemberCode1;
        private Label lblMemberName2;
        private Label lblMemberCode2;
        private Label lblMemberName3;
        private Label lblMemberCode3;
        private Label lblMemberName4;
        private Label lblMemberCode4;
        private Label lblMemberName5;
        private Label lblMemberCode5;
        private Button btnClose;
    }
}