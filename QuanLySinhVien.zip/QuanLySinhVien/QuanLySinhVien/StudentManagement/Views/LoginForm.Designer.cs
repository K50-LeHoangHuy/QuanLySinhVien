namespace StudentManagement
{
    partial class LoginForm
    {
        private System.ComponentModel.IContainer components = null;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        private void InitializeComponent()
        {
            this.SuspendLayout();

            // Form properties - resizable
            this.Text = "Đăng nhập hệ thống";
            this.Size = new System.Drawing.Size(450, 380);
            this.MinimumSize = new System.Drawing.Size(400, 330);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.Sizable;
            this.MaximizeBox = true;
            this.MinimizeBox = true;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.BackColor = System.Drawing.Color.FromArgb(245, 245, 245);

            // Panel chính
            System.Windows.Forms.Panel pnlMain = new System.Windows.Forms.Panel();
            pnlMain.Location = new System.Drawing.Point(20, 20);
            pnlMain.Size = new System.Drawing.Size(390, 310);
            pnlMain.Anchor = System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right | System.Windows.Forms.AnchorStyles.Bottom;
            pnlMain.BackColor = System.Drawing.Color.White;
            pnlMain.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.Controls.Add(pnlMain);

            // Header
            System.Windows.Forms.Label lblHeader = new System.Windows.Forms.Label();
            lblHeader.Text = "🔐 ĐĂNG NHẬP HỆ THỐNG";
            lblHeader.Font = new System.Drawing.Font("Segoe UI", 16, System.Drawing.FontStyle.Bold);
            lblHeader.ForeColor = System.Drawing.Color.FromArgb(70, 130, 180);
            lblHeader.Size = new System.Drawing.Size(350, 40);
            lblHeader.Location = new System.Drawing.Point(20, 20);
            lblHeader.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            lblHeader.Anchor = System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right;
            pnlMain.Controls.Add(lblHeader);

            // Username Label
            System.Windows.Forms.Label lblUsername = new System.Windows.Forms.Label();
            lblUsername.Text = "Tên đăng nhập:";
            lblUsername.Font = new System.Drawing.Font("Segoe UI", 10);
            lblUsername.Size = new System.Drawing.Size(120, 25);
            lblUsername.Location = new System.Drawing.Point(30, 80);
            lblUsername.Anchor = System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left;
            pnlMain.Controls.Add(lblUsername);

            // Username TextBox
            System.Windows.Forms.TextBox txtUsername = new System.Windows.Forms.TextBox();
            txtUsername.Name = "txtUsername";
            txtUsername.Font = new System.Drawing.Font("Segoe UI", 10);
            txtUsername.Size = new System.Drawing.Size(200, 25);
            txtUsername.Location = new System.Drawing.Point(160, 80);
            txtUsername.Anchor = System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right;
            pnlMain.Controls.Add(txtUsername);

            // Password Label
            System.Windows.Forms.Label lblPassword = new System.Windows.Forms.Label();
            lblPassword.Text = "Mật khẩu:";
            lblPassword.Font = new System.Drawing.Font("Segoe UI", 10);
            lblPassword.Size = new System.Drawing.Size(120, 25);
            lblPassword.Location = new System.Drawing.Point(30, 120);
            lblPassword.Anchor = System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left;
            pnlMain.Controls.Add(lblPassword);

            // Password TextBox
            System.Windows.Forms.TextBox txtPassword = new System.Windows.Forms.TextBox();
            txtPassword.Name = "txtPassword";
            txtPassword.Font = new System.Drawing.Font("Segoe UI", 10);
            txtPassword.Size = new System.Drawing.Size(200, 25);
            txtPassword.Location = new System.Drawing.Point(160, 120);
            txtPassword.UseSystemPasswordChar = true;
            txtPassword.Anchor = System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right;
            txtPassword.KeyPress += TxtPassword_KeyPress;
            pnlMain.Controls.Add(txtPassword);

            // Error Label
            System.Windows.Forms.Label lblError = new System.Windows.Forms.Label();
            lblError.Name = "lblError";
            lblError.Text = "";
            lblError.Font = new System.Drawing.Font("Segoe UI", 9, System.Drawing.FontStyle.Italic);
            lblError.ForeColor = System.Drawing.Color.Red;
            lblError.Size = new System.Drawing.Size(330, 40);
            lblError.Location = new System.Drawing.Point(30, 160);
            lblError.Anchor = System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right;
            lblError.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            pnlMain.Controls.Add(lblError);

            // Buttons Panel
            System.Windows.Forms.Panel pnlButtons = new System.Windows.Forms.Panel();
            pnlButtons.Size = new System.Drawing.Size(350, 50);
            pnlButtons.Location = new System.Drawing.Point(20, 240);
            pnlButtons.Anchor = System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right;
            pnlMain.Controls.Add(pnlButtons);

            // Login Button
            System.Windows.Forms.Button btnLogin = new System.Windows.Forms.Button();
            btnLogin.Text = "Đăng nhập";
            btnLogin.Size = new System.Drawing.Size(120,35);
            btnLogin.Location = new System.Drawing.Point(50, 10);
            btnLogin.BackColor = System.Drawing.Color.FromArgb(70, 130, 180);
            btnLogin.ForeColor = System.Drawing.Color.White;
            btnLogin.Font = new System.Drawing.Font("Segoe UI", 10, System.Drawing.FontStyle.Bold);
            btnLogin.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            btnLogin.Anchor = System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left;
            btnLogin.Click += BtnLogin_Click;
            pnlButtons.Controls.Add(btnLogin);

            // Exit Button
            System.Windows.Forms.Button btnExit = new System.Windows.Forms.Button();
            btnExit.Text = "Thoát";
            btnExit.Size = new System.Drawing.Size(100, 35);
            btnExit.Location = new System.Drawing.Point(200, 10);
            btnExit.BackColor = System.Drawing.Color.Gray;
            btnExit.ForeColor = System.Drawing.Color.White;
            btnExit.Font = new System.Drawing.Font("Segoe UI", 10, System.Drawing.FontStyle.Bold);
            btnExit.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            btnExit.Anchor = System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right;
            btnExit.Click += BtnExit_Click;
            pnlButtons.Controls.Add(btnExit);

            this.ResumeLayout(false);
        }

        #endregion
    }
}