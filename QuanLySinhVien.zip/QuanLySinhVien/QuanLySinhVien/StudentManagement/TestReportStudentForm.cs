using System;
using System.Windows.Forms;
using StudentManagement.Views;

namespace StudentManagement
{
    public class TestReportStudentForm
    {
        // NOTE: Method Main() đã được comment vì Program.cs đã có entry point
        // Sử dụng: dotnet run reportstudentform
        
        /*
        [STAThread]
        public static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            
            Console.WriteLine("🚀 ĐANG KHỞI CHẠY REPORTSTUDENTFORM...");
            Console.WriteLine("========================================");
            Console.WriteLine("📊 Form báo cáo sinh viên");
            Console.WriteLine("✅ Chức năng:");
            Console.WriteLine("   - Hiển thị danh sách sinh viên với LINQ JOIN");
            Console.WriteLine("   - Lọc theo lớp");
            Console.WriteLine("   - Tìm kiếm theo tên/mã sinh viên");
            Console.WriteLine("   - Xuất Excel (ClosedXML)");
            Console.WriteLine("   - In báo cáo");
            Console.WriteLine("========================================\n");
            
            try
            {
                Application.Run(new ReportStudentForm());
                Console.WriteLine("✅ Form đã đóng thành công!");
            }
            catch (Exception ex)
            {
                Console.WriteLine($"❌ LỖI: {ex.Message}");
                Console.WriteLine($"📝 Chi tiết: {ex.StackTrace}");
            }
        }
        */
    }
}
